export default (val) => {
  console.log(val);
};
