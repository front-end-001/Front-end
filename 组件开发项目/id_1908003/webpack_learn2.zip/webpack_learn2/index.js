import test from './test';

test(123123123);
console.log(1);

const a = [123, 234234];

for (let val of a) {
  test(val);
}

class Comp {}

const test1 = <Comp></Comp>