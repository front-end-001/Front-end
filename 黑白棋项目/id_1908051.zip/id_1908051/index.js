window.onload = function() {
    let map = [
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, 0, 0, 1, 2]
    ]
    let color = 1;
    let checkerboard = document.getElementById('checkerboard');
    render();
    function checkPass() {
        console.log(`check ${color === 1 ? '黑色' : '白色'}`)
        for (let i = 0; i < 8; i++) {
            for (let j = 0; j < 8; j++) {
                if (move(i, j, true));
                    return false;
            }
        }
        return true;
    }
    function move(i, j, checkOnly) {
        if (map[i][j] > 0)
            return;
        let directions = [
            {x: -1, y: -1},
            {x: -1, y: 0},
            {x: -1, y: 1},
            {x: 0, y: 1},
            {x: 1, y: 1},
            {x: 1, y: 0},
            {x: 1, y: -1},
            {x: 0, y: -1}
        ]
        let moveSucess = false;
        for (let direction of directions) {
            let canMove = false;
            let [x, y] = [j, i];
            while (true) {
                x += direction.x;
                y += direction.y;
                if (x < 0 || x >= 8 || y < 0 || y >= 8) {
                    canMove = false;
                    break;
                }
                if (map[y][x] === color) {
                    canMove = true;
                } else if (map[y][x] === 3 - color) {
                    break;
                } else if (map[y][x] === 0) {
                    canMove = false;
                    break;
                }
            }
            moveSucess = moveSucess || canMove;
            if (canMove && !checkOnly) {
                while(true) {
                    x -= direction.x;
                    y -= direction.y;
                    map[y][x] = 3 - color;
                    if (x === j && y === i)
                        break;
                }
            }
        }
        return moveSucess;
    }
    function render() {
        console.log(`当前玩家：${color === 1 ? '黑' : '白'}`);
        checkerboard.innerHTML = '';
        for (let i = 0; i < 8; i++) {
            let row = document.createElement('ul');
            row.classList.add('row');
            checkerboard.appendChild(row);
            for (let j = 0; j < 8; j++) {
                let col = document.createElement('li');
                col.classList.add('col');
                col.addEventListener('click', event => {
                    if (move(i, j, false)) {
                        color = 3 - color;
                        if (checkPass()) {
                            console.log('pass');
                            color = 3 - color;
                            if(checkPass()) {
                                alert('game over');
                            }
                        }
                        render();
                    }
                })
                if (map[i][j] === 1) {
                    col.classList.add('white');
                }
                if (map[i][j] === 2) {
                    col.classList.add('black');
                }
                row.appendChild(col);
            }
        }
    }
}