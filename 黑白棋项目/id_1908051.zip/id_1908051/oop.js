window.onload = function() {
    class OthelloPattern {
        constructor() {
            this.map = [
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 2, 0, 0, 0],
                [0, 0, 0, 2, 1, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0]
            ]
        }
        checkPass() {
            console.log(`check ${this.color === 1 ? '黑色' : '白色'}`)
            for (let i = 0; i < 8; i++) {
                for (let j = 0; j < 8; j++) {
                    if (this.move(i, j, true));
                        return false;
                }
            }
            return true;
        }
        move(i, j, checkOnly) {
            if (this.map[i][j] > 0)
                return;
            let directions = [
                {x: -1, y: -1},
                {x: -1, y: 0},
                {x: -1, y: 1},
                {x: 0, y: 1},
                {x: 1, y: 1},
                {x: 1, y: 0},
                {x: 1, y: -1},
                {x: 0, y: -1}
            ]
            let moveSucess = false;
            for (let direction of directions) {
                let canMove = false;
                let [x, y] = [j, i];
                while (true) {
                    x += direction.x;
                    y += direction.y;
                    if (x < 0 || x >= 8 || y < 0 || y >= 8) {
                        canMove = false;
                        break;
                    }
                    if (this.map[y][x] === this.color) {
                        canMove = true;
                    } else if (this.map[y][x] === 3 - this.color) {
                        break;
                    } else if (this.map[y][x] === 0) {
                        canMove = false;
                        break;
                    }
                }
                moveSucess = moveSucess || canMove;
                if (canMove && !checkOnly) {
                    while(true) {
                        x -= direction.x;
                        y -= direction.y;
                        this.map[y][x] = 3 - this.color;
                        if (x === j && y === i)
                            break;
                    }
                }
            }
            return moveSucess;
        }
    }
    class OthelloGame {
        constructor() {
            this.pattern = new OthelloPattern();
            this.color = 1;
        }
        move(i, j, checkOnly) {
            if (this.pattern.move(i, j, checkOnly)) {
                this.color = 3 - this.color;
                if (this.pattern.checkPass()) {
                    console.log('pass');
                    this.color = 3 - this.color;
                    if(this.pattern.checkPass()) {
                        alert('game over');
                    }
                }
                this.render();
            }
        }
    }
    class OthelloView {
        constructor(game, container) {
            this.game = game;
            this.container = container;
        }
        render() {
            console.log(`当前玩家：${this.game.color === 1 ? '黑' : '白'}`);
            this.container.innerHTML = '';
            for (let i = 0; i < 8; i++) {
                let row = document.createElement('ul');
                row.classList.add('row');
                this.container.appendChild(row);
                for (let j = 0; j < 8; j++) {
                    let col = document.createElement('li');
                    col.classList.add('col');
                    col.addEventListener('click', event => {
                        this.game.move(i, j, false);
                    })
                    if (this.game.pattern.map[i][j] === 1) {
                        col.classList.add('white');
                    }
                    if (this.game.pattern.map[i][j] === 2) {
                        col.classList.add('black');
                    }
                    row.appendChild(col);
                }
            }
        }

    }
    new OthelloView(new OthelloGame(),
    document.getElementById('checkerboard')).render();
}